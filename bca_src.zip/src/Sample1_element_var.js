import React from "react";

const Sample1_element_var = props => {
  let { mychoice } = props;
  let mycomponent;
  
  if (mychoice==="1") {
    mycomponent=<h1>Hello World {mychoice} </h1>
  } else {
    mycomponent=<h1>Bye World {mychoice} </h1>
  }

  return mycomponent;

};

export default Sample1_element_var;