import React, { Component } from 'react';  

class FirstClass extends React.Component {  
    render() {  
       return (  
          <div className="App">  
             <h1>Hello World From Class</h1>  
          </div>  
       );  
    }  
 }  
 export default FirstClass;