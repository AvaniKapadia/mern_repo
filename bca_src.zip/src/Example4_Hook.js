import React, { useState } from 'react';

const Example4_hook = () => {
  return <Headline />;
};


// The useState hook takes an initial state as parameter and returns an array 
// which holds the current state as first item and a function to change the state 
// as second item. We are using JavaScript array destructuring to access both items
// with a shorthand expression. In addition, the destructuring let's us name 
// the variables ourselves.

const Headline = () => {
  const [greeting, setGreeting] = useState(
    'Hello  hook sample!'
  );

  return <h1>{greeting}</h1>;
};

export default Example4_hook;