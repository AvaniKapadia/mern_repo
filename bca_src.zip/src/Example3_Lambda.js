import React from 'react';

//lambda or arrow function method for creating Functional Component
const Example3_Lambda = () => {
  const greeting = 'Hello Intellect using lambda function';

  return <Headline value={greeting} />;
};

const Headline = ({ value }) => {
  return <h1>{value}</h1>;
};

export default Example3_Lambda;



