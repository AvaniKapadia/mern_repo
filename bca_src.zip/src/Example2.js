import React from 'react';


function Example2() {
  const user = 'Intellect !';

  return <Headline name={user} />;
}

// Using props without props keyword
function Headline({ name }) {
  return <h1>{name}</h1>;
}

export default Example2;