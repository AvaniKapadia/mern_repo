import React, { useState } from 'react';

const Example5_Hook = () => {
  return <Headline />;
};

const Headline = () => {
  const [user, setUser] = useState(
    'Guest'
  );

  const handleChange = event => setUser(event.target.value);

  return (
    <div>
      <h1>Hello {user}</h1>

      Name <input type="text" value={user} onChange={handleChange} />
    </div>
  );
};

export default Example5_Hook;