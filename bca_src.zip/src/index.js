import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';

import {
  BrowserRouter as Router,
  Routes,
  Route,
} from "react-router-dom";

import First from './First'
import FirstClass from './FirstClass'
import Example1 from './Example1';
import Example2 from './Example2';

import Example3_Lambda from './Example3_Lambda';
import Example4_Hook from './Example4_Hook';
import Example5_Hook from './Example5_Hook';
import Example6_Hook from './Example6_Hook';
import Sample1_if_else from './Sample1_if_else';
import Sample1_switch from './Sample1_switch';
import Sample1_element_var from './Sample1_element_var';
import Sample1_turnary from './Sample1_turnary';
import Sample1_short_circuit from './Sample1_short_circuit';
import Sample1_iifes from './Sample1_iifes';
const root = ReactDOM.createRoot(document.getElementById('root'));
root.render(
  <React.StrictMode>
    {/* <First name="INTELLECT COMPUTERS "/>
    <FirstClass/>
    <Example1/>
    <Example2/>
    <Example3_Lambda/>
    <Example4_Hook/>
    
    <Example5_Hook/>
    <Example6_Hook/> */}
    <Router>
      
      <Routes>
          <Route path="/" element={<App />} />
          <Route path="/Sample_if_else" element={ <Sample1_if_else mychoice={2} />} />
          <Route path="/Sample_switch" element={<Sample1_switch  mychoice="2" />} />
          <Route path="/Sample1_element_var" element={<Sample1_element_var  mychoice="1" />} />
          <Route path="/Sample1_turnary" element={<Sample1_turnary mychoice="2" />} />
          <Route path="/Sample1_short_circuit" element={<Sample1_short_circuit mychoice="1" />} />
          <Route path="/Sample1_IIFEs" element={<Sample1_iifes mychoice="11" />} />
        
        
      </Routes>
    
  
    
    </Router>
  </React.StrictMode>
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
