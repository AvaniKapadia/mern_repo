import React from "react";

 
const Sample1_short_circuit = props => {
  let { mychoice } = props;
  
  return (mychoice==1) && <h1>Hello World {mychoice} </h1>  
  
};

export default Sample1_short_circuit;