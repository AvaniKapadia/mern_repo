import React from "react";

 
const Sample1_iifes = props => {
  let { mychoice } = props;

 return (
    <div className="App">
      <h1>
        This is a Demo Code
      </h1>
      {/* Method1 */}
      {/* {(function() {
        if (mychoice=="1") {
          return (
          <div>
            <form>
              <h1> Login </h1>
              Name <input type="text" name="t1" /> <br/>
              Password <input type="text" name="t2" /> <br/>
               <input type="submit" name="s1" /> <br/>
            </form>
            </div>
          )
        } else {
          return (
          <div>
            <form>
              <h1> Login </h1>
              Name <input type="text" name="t1" /> <br/>
              Password <input type="text" name="t2" /> <br/>
              Email<input type="email" name="t2" /> <br/>
               <input type="submit" name="s1" /> <br/>
            </form>
            </div>
          )
        }
      })()} */}
{/* Method2 */}
{(() => {
        if (mychoice=="1") {
          return (
          <div>
            <form>
              <h1> Login </h1>
              Name <input type="text" name="t1" /> <br/>
              Password <input type="text" name="t2" /> <br/>
               <input type="submit" name="s1" /> <br/>
            </form>
            </div>
          )
        } else {
          return (
          <div>
            <form>
              <h1> Login </h1>
              Name <input type="text" name="t1" /> <br/>
              Password <input type="text" name="t2" /> <br/>
              Email<input type="email" name="t2" /> <br/>
               <input type="submit" name="s1" /> <br/>
            </form>
            </div>
          )
        }
      })()}
    </div>
 )
  
    };
    
    export default Sample1_iifes;