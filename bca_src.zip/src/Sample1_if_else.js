import React from "react";

 
const Sample1_if_else = props => {
  let { mychoice } = props;

  if (mychoice==1) {
    return <h1>Hello World {mychoice} </h1>
  } else {
    return <h1>Bye World {mychoice} </h1>
  }
};

export default Sample1_if_else;