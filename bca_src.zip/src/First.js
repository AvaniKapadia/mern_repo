//npm install react-router-dom
//Working with Props (Property)
function First(props) {
    const text = 'Hello World';
    
    return (
      <div className="App">
        <p> {text} </p>
        <h1>Hello, {props.name}</h1>;
      </div>
    );
  }

  
export default First;