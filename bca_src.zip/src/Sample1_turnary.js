import React from "react";

 
const Sample1_turnary = props => {
  let { mychoice } = props;
  
  return (mychoice==1)? <h1>Hello World {mychoice} </h1>  : <h1>Bye World {mychoice} </h1>
  
};

export default Sample1_turnary;