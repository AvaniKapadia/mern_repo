import React from "react";
 
const Sample1_switch = props => {
  let { mychoice } = props;
 
  switch (mychoice) 
  {
  case "1":
        return <h1>Hello World {mychoice} </h1>;
      
  case "2":
      return <h1>Bye World {mychoice} </h1>;
      
 case "3":
        return <h1>Change World {mychoice} </h1>;
        
 default:
      return null;
      
  }

  
};




export default Sample1_switch;