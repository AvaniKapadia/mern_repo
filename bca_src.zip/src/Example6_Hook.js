import React, { useState } from 'react';

const Example6_Hook = () => {
  return <Headline />;
};

const Headline = () => {
  const [user, setUser] = useState('Guest1' );
  const [pass, setPassword] = useState('');

  const handleChange = event => setUser(event.target.value);
  const handleChange2 = event => setPassword(event.target.value);
//   handleClick = () => {
//     console.log('this is:', this);
//   }

const onClick1=() =>
{
    if (user=="react" && pass=="easy")
        alert("Welcome ...."+ user);
    else
        alert("sorry");
}

  return (
    <div>
      <h1>Hello {user}</h1>

      Name <input type="text" value={user} onChange={handleChange} /> <br/>
      pass <input type="text" value={pass} onChange={handleChange2} /><br/>
      <input type="button" value="Submit" onClick={onClick1} /><br/>
    </div>
  );
};

export default Example6_Hook;